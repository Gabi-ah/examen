module ApartmentHelper
end
